package com.isgit.multum;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MultumServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
