package com.isgit.multum.exception;

/**
 *
 * @author Prabhaker Goli
 */
public abstract class ApiSubError {

}
