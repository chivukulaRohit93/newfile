package com.isgit.multum.constant;

import java.util.regex.Pattern;

/**
 *
 * @author Prabhaker Goli
 */
public class ApplicationConstant {

    public static final String CREATED_SUCCESS = " Created successfully";
    public static final String CREATE_ERROR = "Error occurred while creating";
    public static final String DELETED_SUCCESS = "Deleted successfully";
    public static final String DELETE_ERROR = "Error occurred while deleting";
    public static final String UPDATED_SUCCESS = " Updated successfully";
    public static final String UPDAte_ERROR = "Error occurred while updating";
    public static final String DUPLICATE_ERROR = "Duplicate record";

    public static final Pattern VALID_EMAIL_ADDRESS_REGEX = Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$", Pattern.CASE_INSENSITIVE);
}
