package com.isgit.multum.service.impl;

import com.isgit.multum.dto.UserDto;
import com.isgit.multum.entity.User;
import com.isgit.multum.mapper.UserMapper;
import com.isgit.multum.repository.UserRepository;
import com.isgit.multum.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

/**
 *
 * @author Prabhaker Goli
 */
@RequiredArgsConstructor
@Service
@Transactional
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;

    private final UserMapper userMapper;

    @Transactional(propagation = Propagation.REQUIRED)
    @Override
    public UserDto save(UserDto userDto) {
        User user = userRepository.save(userMapper.toEntity(userDto));
        return userMapper.toDto(user);
    }

    @Transactional(readOnly = true)
    @Override
    public Optional<UserDto> findById(long id) {
        if(userRepository.findById(id).isPresent()) {
            return Optional.of(userMapper.toDto(userRepository.findById(id).get()));
        } else {
            return Optional.ofNullable(null);
        }
    }

    @Override
    public boolean existsById(long id) {
        return userRepository.existsById(id);
    }

    @Override
    public List<UserDto> findAll() {

        return userMapper.toDto(userRepository.findAll());
    }

    @Override
    public long count() {
        return userRepository.count();
    }

    @Override
    public void deleteById(long id) {
        userRepository.deleteById(id);
    }

    @Override
    public void delete(UserDto userDto) {
        userRepository.delete(userMapper.toEntity(userDto));
    }

    @Override
    public void deleteAll() {
        userRepository.deleteAll();
    }

    @Override
    public UserDto findByUsername(String username) {

        return userMapper.toDto(userRepository.findByPhoneNumber(username));
    }
}
