package com.isgit.multum.config;

import org.springframework.context.annotation.Configuration;

/**
 *
 * @author Prabhaker Goli
 */
@Configuration
public class SwaggerConfig {
}
