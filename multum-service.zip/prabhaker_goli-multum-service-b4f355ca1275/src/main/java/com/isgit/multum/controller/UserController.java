package com.isgit.multum.controller;

import com.isgit.multum.aspect.LogExecutionTime;
import com.isgit.multum.dto.UserDto;
import com.isgit.multum.exception.ResourceNotFoundException;
import com.isgit.multum.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.io.IOException;
import java.net.URI;
import java.util.List;
import java.util.Optional;

@Slf4j
@RequiredArgsConstructor
@RestController
@RequestMapping("/api/users")
public class UserController {

    private final UserService userService;

    private final PasswordEncoder passwordEncoder;

    @LogExecutionTime
    @GetMapping(value = { "", "/" }, produces = "application/json")
    public List<UserDto> list() {
        return userService.findAll();
    }

    @LogExecutionTime
    @PostMapping(value = "/", produces = "application/json")
    public List<UserDto> findAll(@RequestBody UserDto input) {

        return userService.findAll();
    }

    @LogExecutionTime
    @GetMapping(value = "/{id}", produces = "application/json")
    public UserDto findById(@PathVariable(value = "id") long id) {

        return userService.findById(id).orElseThrow(() -> new ResourceNotFoundException("User", "id", id));
    }

    @LogExecutionTime
    @GetMapping(value = "/findByEmail", produces = "application/json")
    public UserDto findByEmail(@RequestParam(value = "email") String email) {

        Optional<UserDto> userDto = Optional.of(userService.findByUsername(email));

        return userDto.orElseThrow(() -> new ResourceNotFoundException("User", "emailId", email));
    }

    @LogExecutionTime
    @PostMapping(produces = "application/json")
    public ResponseEntity<?> save(@RequestBody UserDto userDto) {

        UserDto savedUserDto = userService.save(userDto);

        URI location = ServletUriComponentsBuilder.fromCurrentRequest()
                .path("/{id}")
                .buildAndExpand(savedUserDto.getId())
                .toUri();

        return ResponseEntity.created(location).build();
    }

    @LogExecutionTime
    @PutMapping(value = "/{id}", produces = "application/json")
    public ResponseEntity<?> update(@PathVariable(value = "id") Long id, @RequestBody UserDto userDto) {
        Optional<UserDto> userOptional = userService.findById(id);

        if (!userOptional.isPresent())
            return ResponseEntity.notFound().build();

        userDto.setId(id);

        userService.save(userDto);

        return ResponseEntity.noContent().build();
    }

    @LogExecutionTime
    @DeleteMapping(value = "/{id}", produces = "application/json")
    public ResponseEntity<?> delete(@PathVariable(value = "id") Long id) {
        UserDto role = userService.findById(id).orElseThrow(() -> new ResourceNotFoundException("User", "id", id));

        userService.delete(role);

        return ResponseEntity.ok().build();
    }


    @LogExecutionTime
    @PostMapping(value = "/profile", produces = "application/json", consumes = { "multipart/form-data" })
    public ResponseEntity<?> profile(@RequestPart("user") UserDto userDto,
                                     @RequestPart(value = "profilePicture", required = false) MultipartFile profilePicture) {

        UserDto user = userService.findById(userDto.getId())
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", userDto.getId() ));

        user.setFirstName(userDto.getFirstName());
        user.setMiddleName(userDto.getMiddleName());
        user.setLastName(userDto.getLastName());
        user.setEmailId(userDto.getEmailId());
        user.setPhoneNumber(userDto.getPhoneNumber());
        user.setRecoveryEmailId(userDto.getRecoveryEmailId());

//        Role role = roleService.findById(rUser.getRole().getId()).orElseThrow(() -> new ResourceNotFoundException("Role", "id", rUser.getRole().getId()));
//        user.setRole(role);

        String encrypted = passwordEncoder.encode(userDto.getPassword());
        // Setting password
        if (userDto.getPassword().equalsIgnoreCase(user.getPassword())) {
            // Password has not changed
            log.info(":: Password has not changed ::");
            user.setPassword(userDto.getPassword());
        } else {
            // Password has changed
            log.info(":: Password has changed ::");
            user.setPassword(encrypted);
        }

        // Update
        if (profilePicture != null && !profilePicture.isEmpty()) {
            try {
                user.setProfilePicture(profilePicture.getBytes());
            } catch (IOException e) {
                log.error("Exception occurred in profile() profile picture upload");
            }
        }

        userService.save(user);

        return ResponseEntity.ok().build();
    }

    @LogExecutionTime
    @GetMapping(value = "/user-profile", produces = "application/json")
    public ResponseEntity<?> getUserProfile() {

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication == null || !authentication.isAuthenticated()) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }
        UserDto userDto = userService.findByUsername(authentication.getName());
        if(userDto == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        return ResponseEntity.ok(userDto);
    }

    @LogExecutionTime
    @GetMapping(value = "/profile-picture", produces = { MediaType.IMAGE_JPEG_VALUE, MediaType.IMAGE_PNG_VALUE })
    public ResponseEntity<?> profilePicture() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication == null || !authentication.isAuthenticated()) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }
        UserDto userDto = userService.findByUsername(authentication.getName());
        if(userDto != null) {
            byte[] bytes = userDto.getProfilePicture();
            return ResponseEntity
                    .ok()
                    //.contentType(MediaType.IMAGE_JPEG)
                    .body(bytes);
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }
    }
}
