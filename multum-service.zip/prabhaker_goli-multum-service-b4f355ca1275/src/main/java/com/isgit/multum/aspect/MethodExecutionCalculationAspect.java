package com.isgit.multum.aspect;

import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

import java.util.concurrent.TimeUnit;

/**
 *
 * @author Prabhaker Goli
 */
@Slf4j
@Aspect
@Configuration
@EnableAspectJAutoProxy(proxyTargetClass = true)
public class MethodExecutionCalculationAspect {

    /**
     * Calculate the method execution time.
     *
     * @param joinPoint
     * @return Object
     * @throws Throwable
     */
    @Around("@annotation(LogExecutionTime)")
    public Object around(ProceedingJoinPoint joinPoint) throws Throwable {
        log.info(":: Entered into {} ::", joinPoint);
        long startTime = System.currentTimeMillis();

        Object proceed = joinPoint.proceed();

        long timeTaken = System.currentTimeMillis() - startTime;
        long minutes = TimeUnit.MILLISECONDS.toSeconds(timeTaken);
        log.info(":: Exited from {} and Time Taken is {} ::", joinPoint, minutes);
        return proceed;
    }
}
