package com.isgit.multum.repository;

import com.isgit.multum.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 *
 * @author Prabhaker Goli
 */
public interface UserRepository extends JpaRepository<User, Long> {

    User findByEmailId(String emailId);

    User findByPhoneNumber(String phoneNumber);
}
