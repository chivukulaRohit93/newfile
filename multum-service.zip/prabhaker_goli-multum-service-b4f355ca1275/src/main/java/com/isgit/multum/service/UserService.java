package com.isgit.multum.service;

import com.isgit.multum.dto.UserDto;

import java.util.List;
import java.util.Optional;

/**
 *
 * @author Prabhaker Goli
 */
public interface UserService {

    UserDto save(UserDto userDto);

    Optional<UserDto> findById(long id);

    boolean existsById(long id);

    List<UserDto> findAll();

    long count();

    void deleteById(long id);

    void delete(UserDto userDto);

    void deleteAll();

    UserDto findByUsername(String username);

}
