package com.example.demo;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.Register1DTO;

@RestController
@RequestMapping("/api")
public class RegisterController1 {
	 @Autowired
	 private RegisterRepository1 registerRepo1;
	 
	 @Autowired
	 BCryptPasswordEncoder passwordEncoder;
	 
	 @GetMapping("/reg1")
		public List<Register1> getRegister(){
			return this.registerRepo1.findAll();
	 }
	 
	 
	 @PostMapping("/reg1")
	 public Register1 addRegister(@RequestBody Register1 register) {
		 String password = register.getPassword1();
			register.setPassword1(passwordEncoder.encode(password));
			String confirmpassword = register.getConfirmPassword1();
			register.setConfirmPassword1(passwordEncoder.encode(confirmpassword));
		 System.out.println("register "+register.toString());
		 return registerRepo1.save(register);
	 	}
		public ResponseEntity<Register1DTO> saveUserData(@RequestBody Register1DTO dto) {
			Register1 user1 = new Register1();
			user1.setConfirmPassword1(dto.getConfirmPassword1());
			user1.setPassword1(dto.getPassword1());
			user1.setFirstname1(dto.getFirstName1());
			user1.setLastname1(dto.getLastName1());
			user1.setEmail1(dto.getEmail1());
			registerRepo1.save(user1);
			return new ResponseEntity<>(HttpStatus.CREATED);
		}
}
