package com.example.demo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "register1")
public class Register1 {
	
	@Id
	private String email1;
	private String firstname1;
	
	private String lastname1;
	
	
	private String password1;
	
	@Column(name = "confirmpassword1")
	private String confirmPassword1;
	
	private String phone1;
	
	private String zipcode1;
	
	/*
	 * private boolean privacy;
	 * 
	 * private boolean acceptTerms1;
	 */
	
	@Override
	public String toString() {
		return "Register [email1=" + email1 + ", firstname1=" + firstname1 + ", lastname1=" + lastname1 + ", password1="
				+ password1 + ", confirmPassword1=" + confirmPassword1 + ", phone1=" + phone1 + ", zipcode1=" + zipcode1
				+  "]";
	}

	public String getEmail1() {
		return email1;
	}

	public void setEmail1(String email1) {
		this.email1 = email1;
	}

	public String getFirstname1() {
		return firstname1;
	}

	public void setFirstname1(String firstname1) {
		this.firstname1 = firstname1;
	}

	public String getLastname1() {
		return lastname1;
	}

	public void setLastname1(String lastname1) {
		this.lastname1 = lastname1;
	}

	public String getPassword1() {
		return password1;
	}

	public void setPassword1(String password1) {
		this.password1 = password1;
	}

	public String getConfirmPassword1() {
		return confirmPassword1;
	}

	public void setConfirmPassword1(String confirmPassword1) {
		this.confirmPassword1 = confirmPassword1;
	}

	public String getPhone1() {
		return phone1;
	}

	public void setPhone1(String phone1) {
		this.phone1 = phone1;
	}

	public String getZipcode1() {
		return zipcode1;
	}

	public void setZipcode1(String zipcode1) {
		this.zipcode1 = zipcode1;
	}

	/*
	 * public boolean isPrivacy() { return privacy; }
	 * 
	 * public void setPrivacy(boolean privacy) { this.privacy = privacy; }
	 * 
	 * public boolean isAcceptTerms1() { return acceptTerms1; }
	 * 
	 * public void setAcceptTerms1(boolean acceptTerms1) { this.acceptTerms1 =
	 * acceptTerms1; }
	 */

	
}
