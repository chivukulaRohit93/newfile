package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.RegisterDTO;
import com.example.demo.dto.UserDTO;

@RestController
@RequestMapping("/api")

public class RegisterController {

	@Autowired
	private RegisterRepository registerRepo;

	@Autowired
	BCryptPasswordEncoder passwordEncoder;

	@GetMapping("/registers")
	public List<Register> getRegister() {
		return this.registerRepo.findAll();
	}

	@PostMapping("/registers")
	public Register addRegister(@RequestBody Register register) {
		String password = register.getPassword();
		register.setPassword(passwordEncoder.encode(password));
		String confirmpassword = register.getConfirmPassword();
		register.setConfirmPassword(passwordEncoder.encode(confirmpassword));
		System.out.println("register "+register.toString());
		return registerRepo.save(register);
	}

	public ResponseEntity<UserDTO> saveUserData(@RequestBody RegisterDTO dto) {
		Register user = new Register();
		user.setConfirmPassword(dto.getConfirmPassword());
		user.setPassword(dto.getPassword());
		user.setFirstname(dto.getFirstName());
		user.setLastname(dto.getLastName());
		user.setEmail(dto.getEmail());
		registerRepo.save(user);
		return new ResponseEntity<>(HttpStatus.CREATED);
	}

}
