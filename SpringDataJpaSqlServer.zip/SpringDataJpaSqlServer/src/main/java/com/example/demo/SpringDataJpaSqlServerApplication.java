package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(exclude = {
        org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration.class}
        )
public class SpringDataJpaSqlServerApplication /*implements CommandLineRunner*/ {

	@Autowired
	
	public static void main(String[] args) {
		SpringApplication.run(SpringDataJpaSqlServerApplication.class, args);
	}

	/*@Override
	public void run(String... args) throws Exception {
		List <user> user = userRepo.findAll();
		user.forEach(System.out :: println);
	}*/

}
