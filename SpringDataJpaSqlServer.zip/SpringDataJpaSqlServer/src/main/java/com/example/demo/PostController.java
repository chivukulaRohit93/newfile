package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.PostDTO;

@RestController
@RequestMapping("/api")

public class PostController {
	@Autowired
	private PostRepository postRepo;

	@Autowired
	BCryptPasswordEncoder passwordEncoder;

	@GetMapping("/post")
	public List<Post> getPost() {
		return this.postRepo.findAll();
	}

	@PostMapping("/post")
	public Post addpost(@RequestBody Post register) {
		String password = register.getCvv();
		register.setCvv(passwordEncoder.encode(password));
		System.out.println("register "+register.toString());
		return postRepo.save(register);
	}

	public ResponseEntity<PostDTO> saveUserData(@RequestBody PostDTO dto) {
		Post user = new Post();
		user.setPostid(dto.getPostid());
		user.setJobtitle(dto.getJobtitle());
		user.setDateneedstoknow(dto.getDateneedstoknow());
		user.setPickupaddress(dto.getPickupaddress());
		user.setPickupaddress1(dto.getPickupaddress1());
		user.setPickupaddress2(dto.getPickupaddress2());
		user.setDropoffaddress(dto.getDropoffaddress());
		user.setDropoffaddress1(dto.getDropoffaddress1());
		user.setDropoffaddress2(dto.getDropoffaddress2());
		user.setChooseprice(dto.getChooseprice());
		user.setCardnumber(dto.getCardnumber());
		user.setCvv(dto.getCvv());
		user.setCardexpiry(dto.getCardexpiry());
		postRepo.save(user);
		return new ResponseEntity<>(HttpStatus.CREATED);
	}
}
