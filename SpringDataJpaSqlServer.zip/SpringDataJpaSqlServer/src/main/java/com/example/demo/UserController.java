package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.UserDTO;

@RestController
@RequestMapping("/api")
public class UserController {

	@Autowired
	private CustomerRepository UserRepo;

	@Autowired
	BCryptPasswordEncoder passwordEncoder;

	@GetMapping("/users")
	public List<User> getUsers() {
		return this.UserRepo.findAll();
	}

	@GetMapping("/test")
	public String testApi() {
		System.out.println("UserController.testApi()");
		return "Service is hitting";
	}

	@PostMapping("/users")
	public User adduser(@RequestBody User register) {
		String password = register.getPassword();
		register.setPassword(passwordEncoder.encode(password));
		System.out.println(register.toString());
		return UserRepo.save(register);
	}

	public ResponseEntity<UserDTO> saveUserData(@RequestBody UserDTO dto) {
		User user = new User();
		user.setPassword(passwordEncoder.encode(dto.getPassword()));
		user.setUsername(dto.getUserName());
		UserRepo.save(user);
		return new ResponseEntity<>(HttpStatus.CREATED);
	}

}
