package com.example.demo;

import org.springframework.data.jpa.repository.JpaRepository;

public interface RegisterRepository1 extends JpaRepository<Register1, String> {

}
