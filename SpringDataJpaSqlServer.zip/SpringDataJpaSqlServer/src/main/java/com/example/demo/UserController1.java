package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.User1DTO;

@RestController
@RequestMapping("/api")

public class UserController1 {
	
	@Autowired
	private UserRepository UserRepo;

	@Autowired
	BCryptPasswordEncoder passwordEncoder;

	@GetMapping("/user1")
	public List<User1> getUsers1() {
		return this.UserRepo.findAll();
	}
	
	@PostMapping("/user1")
	public User1 adduser1(@RequestBody User1 register) {
		String password = register.getPassword();
		register.setPassword(passwordEncoder.encode(password));
		 return UserRepo.save(register);
	 	}
	public ResponseEntity<User1DTO> saveUserData1(@RequestBody User1DTO dto) {
		User1 user = new User1();
		user.setPassword(passwordEncoder.encode(dto.getPassword()));
		user.setUsername(dto.getUserName());
		UserRepo.save(user);
		return new ResponseEntity<>(HttpStatus.CREATED);
	}

}
