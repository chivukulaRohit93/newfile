package com.example.demo.dto;

public class Register1DTO {
	
	private String firstName1;
	private String lastName1;
	private String email1;
	private String confirmPassword1;
	private String password1;
	public String getFirstName1() {
		return firstName1;
	}
	public void setFirstName1(String firstName1) {
		this.firstName1 = firstName1;
	}
	public String getLastName1() {
		return lastName1;
	}
	public void setLastName1(String lastName1) {
		this.lastName1 = lastName1;
	}
	public String getEmail1() {
		return email1;
	}
	public void setEmail1(String email1) {
		this.email1 = email1;
	}
	public String getConfirmPassword1() {
		return confirmPassword1;
	}
	public void setConfirmPassword1(String confirmPassword1) {
		this.confirmPassword1 = confirmPassword1;
	}
	public String getPassword1() {
		return password1;
	}
	public void setPassword1(String password1) {
		this.password1 = password1;
	}

	

}
