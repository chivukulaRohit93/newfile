package com.example.demo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "post")

public class Post {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "postid", nullable = false, unique = true)
	private Integer postid;
	private String jobtitle;
	private String dateneedstoknow;
	private String pickupaddress;
	private String pickupaddress1;
	private String pickupaddress2;
	private String pickupaddress3;
	private String pickupaddress4;
	private String dropoffaddress;
	private String dropoffaddress1;
	private String dropoffaddress2;
	private String dropoffaddress3;
	private String dropoffaddress4;
	private String chooseprice;
	private String cardnumber;
	private String cvv;
	private String cardexpiry;
	public Integer getPostid() {
		return postid;
	}
	public void setPostid(Integer postid) {
		this.postid = postid;
	}
	public String getJobtitle() {
		return jobtitle;
	}
	public void setJobtitle(String jobtitle) {
		this.jobtitle = jobtitle;
	}
	public String getDateneedstoknow() {
		return dateneedstoknow;
	}
	public void setDateneedstoknow(String dateneedstoknow) {
		this.dateneedstoknow = dateneedstoknow;
	}
	public String getPickupaddress() {
		return pickupaddress;
	}
	public void setPickupaddress(String pickupaddress) {
		this.pickupaddress = pickupaddress;
	}
	public String getPickupaddress1() {
		return pickupaddress1;
	}
	public void setPickupaddress1(String pickupaddress1) {
		this.pickupaddress1 = pickupaddress1;
	}
	public String getPickupaddress2() {
		return pickupaddress2;
	}
	public void setPickupaddress2(String pickupaddress2) {
		this.pickupaddress2 = pickupaddress2;
	}
	public String getPickupaddress3() {
		return pickupaddress3;
	}
	public void setPickupaddress3(String pickupaddress3) {
		this.pickupaddress3 = pickupaddress3;
	}
	public String getPickupaddress4() {
		return pickupaddress4;
	}
	public void setPickupaddress4(String pickupaddress4) {
		this.pickupaddress4 = pickupaddress4;
	}
	public String getDropoffaddress() {
		return dropoffaddress;
	}
	public void setDropoffaddress(String dropoffaddress) {
		this.dropoffaddress = dropoffaddress;
	}
	public String getDropoffaddress1() {
		return dropoffaddress1;
	}
	public void setDropoffaddress1(String dropoffaddress1) {
		this.dropoffaddress1 = dropoffaddress1;
	}
	public String getDropoffaddress2() {
		return dropoffaddress2;
	}
	public void setDropoffaddress2(String dropoffaddress2) {
		this.dropoffaddress2 = dropoffaddress2;
	}
	public String getDropoffaddress3() {
		return dropoffaddress3;
	}
	public void setDropoffaddress3(String dropoffaddress3) {
		this.dropoffaddress3 = dropoffaddress3;
	}
	public String getDropoffaddress4() {
		return dropoffaddress4;
	}
	public void setDropoffaddress4(String dropoffaddress4) {
		this.dropoffaddress4 = dropoffaddress4;
	}
	public String getChooseprice() {
		return chooseprice;
	}
	public void setChooseprice(String chooseprice) {
		this.chooseprice = chooseprice;
	}
	public String getCardnumber() {
		return cardnumber;
	}
	public void setCardnumber(String cardnumber) {
		this.cardnumber = cardnumber;
	}
	public String getCvv() {
		return cvv;
	}
	public void setCvv(String cvv) {
		this.cvv = cvv;
	}
	public String getCardexpiry() {
		return cardexpiry;
	}
	public void setCardexpiry(String cardexpiry) {
		this.cardexpiry = cardexpiry;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Post [postid=");
		builder.append(postid);
		builder.append(", jobtitle=");
		builder.append(jobtitle);
		builder.append(", dateneedstoknow=");
		builder.append(dateneedstoknow);
		builder.append(", pickupaddress=");
		builder.append(pickupaddress);
		builder.append(", pickupaddress1=");
		builder.append(pickupaddress1);
		builder.append(", pickupaddress2=");
		builder.append(pickupaddress2);
		builder.append(", pickupaddress3=");
		builder.append(pickupaddress3);
		builder.append(", pickupaddress4=");
		builder.append(pickupaddress4);
		builder.append(", dropoffaddress=");
		builder.append(dropoffaddress);
		builder.append(", dropoffaddress1=");
		builder.append(dropoffaddress1);
		builder.append(", dropoffaddress2=");
		builder.append(dropoffaddress2);
		builder.append(", dropoffaddress3=");
		builder.append(dropoffaddress3);
		builder.append(", dropoffaddress4=");
		builder.append(dropoffaddress4);
		builder.append(", chooseprice=");
		builder.append(chooseprice);
		builder.append(", cardnumber=");
		builder.append(cardnumber);
		builder.append(", cvv=");
		builder.append(cvv);
		builder.append(", cardexpiry=");
		builder.append(cardexpiry);
		builder.append("]");
		return builder.toString();
	}
	
	
}
