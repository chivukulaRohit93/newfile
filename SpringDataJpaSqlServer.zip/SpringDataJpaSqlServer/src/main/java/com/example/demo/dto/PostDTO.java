package com.example.demo.dto;

import java.io.Serializable;

public class PostDTO  implements Serializable {
	
	private Integer postid;
	private String jobtitle;
	private String dateneedstoknow;
	private String pickupaddress;
	private String pickupaddress1;
	private String pickupaddress2;
	private String dropoffaddress;
	private String dropoffaddress1;
	private String dropoffaddress2;
	private String chooseprice;
	private String cardnumber;
    private String cvv;
    private String cardexpiry;
	public Integer getPostid() {
		return postid;
	}
	public void setPostid(Integer postid) {
		this.postid = postid;
	}
	public String getJobtitle() {
		return jobtitle;
	}
	public void setJobtitle(String jobtitle) {
		this.jobtitle = jobtitle;
	}
	public String getDateneedstoknow() {
		return dateneedstoknow;
	}
	public void setDateneedstoknow(String dateneedstoknow) {
		this.dateneedstoknow = dateneedstoknow;
	}
	public String getPickupaddress() {
		return pickupaddress;
	}
	public void setPickupaddress(String pickupaddress) {
		this.pickupaddress = pickupaddress;
	}
	public String getPickupaddress1() {
		return pickupaddress1;
	}
	public void setPickupaddress1(String pickupaddress1) {
		this.pickupaddress1 = pickupaddress1;
	}
	public String getPickupaddress2() {
		return pickupaddress2;
	}
	public void setPickupaddress2(String pickupaddress2) {
		this.pickupaddress2 = pickupaddress2;
	}
	public String getDropoffaddress() {
		return dropoffaddress;
	}
	public void setDropoffaddress(String dropoffaddress) {
		this.dropoffaddress = dropoffaddress;
	}
	public String getDropoffaddress1() {
		return dropoffaddress1;
	}
	public void setDropoffaddress1(String dropoffaddress1) {
		this.dropoffaddress1 = dropoffaddress1;
	}
	public String getDropoffaddress2() {
		return dropoffaddress2;
	}
	public void setDropoffaddress2(String dropoffaddress2) {
		this.dropoffaddress2 = dropoffaddress2;
	}
	public String getChooseprice() {
		return chooseprice;
	}
	public void setChooseprice(String chooseprice) {
		this.chooseprice = chooseprice;
	}
	public String getCardnumber() {
		return cardnumber;
	}
	public void setCardnumber(String cardnumber) {
		this.cardnumber = cardnumber;
	}
	public String getCvv() {
		return cvv;
	}
	public void setCvv(String cvv) {
		this.cvv = cvv;
	}
	public String getCardexpiry() {
		return cardexpiry;
	}
	public void setCardexpiry(String cardexpiry) {
		this.cardexpiry = cardexpiry;
	}
    
	
}
